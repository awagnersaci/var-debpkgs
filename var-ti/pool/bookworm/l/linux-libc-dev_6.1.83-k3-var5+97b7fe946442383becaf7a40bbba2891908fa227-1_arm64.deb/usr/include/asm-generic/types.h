/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_GENERIC_TYPES_H
#define _ASM_GENERIC_TYPES_H
/*
 * int-ll64 is used everywhere now.
 */
#include <asm-generic/int-ll64.h>

#endif /* _ASM_GENERIC_TYPES_H */
